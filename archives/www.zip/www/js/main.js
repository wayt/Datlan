$(document).ready(function(){
		// Nav
		$('#back').hide();
		$('nav ul li a').click(function(){
			$('html, body').animate({
				'scrollTop':   $($(this).attr('href')).offset().top
			}, 500);
			return false;
		});
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100)
				$('#back').fadeIn();
			else
				$('#back').fadeOut();
		});
		$('#back').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 500);
			return false;
		});
		
		// Box
		$('#box').hide();
		$('#register').click(function(){
			$('#box').fadeIn();
		});
		$("#box .content").click(function(event){
			event.stopPropagation();
		}); 
		$('#box').click(function(){
			$('#box').fadeOut();
		});
		
		// Map
		var datlan = new google.maps.LatLng(48.69247,  6.18811);
                var options = {
			center: datlan,
			zoom: 17,
			mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map = new google.maps.Map(document.getElementById("map"), options);
		var infowindow = new google.maps.InfoWindow({
			content: '<div style="width: 300px; height: 100px; padding: 10px;">80. rue Saint Georges<br />54000 NANCY</div>'
		});
		
		var marker = new google.maps.Marker({
			title: 'Datlan',
			map: map,
			position: datlan
		});
		infowindow.open(map, marker);
		google.maps.event.addListener(marker, 'click', function() {
			infowindow.open(map,marker);
		});

});